/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.polymorphismdemo;

public class PolymorphismDemo {
    public static void main(String[] args) {
        // Compile-time polymorphism (method overloading)
        OverloadExample overloadExample = new OverloadExample();
        System.out.println(overloadExample.add(5, 3));           // Output: 8
        System.out.println(overloadExample.add(5.5, 3.3));       // Output: 8.8
        System.out.println(overloadExample.add("Hello ", "World")); // Output: Hello World

        // Runtime polymorphism (method overriding)
        BaseClass base = new BaseClass();
        DerivedClass derived = new DerivedClass();

        BaseClass baseRef;

        baseRef = base;
        baseRef.show(); // Output: BaseClass show method

        baseRef = derived;
        baseRef.show(); // Output: DerivedClass show method
    }
}
