package Task8;

public class Driver {
	  public static void main(String[] args) {
	    // Create points for the triangle vertices
	    Point p1 = new Point(1, 1);
	    Point p2 = new Point(4, 5);
	    Point p3 = new Point(2, 3);

	    // Create lines for the triangle sides
	    Line sideA = new Line(p1, p2);
	    Line sideB = new Line(p2, p3);
	    Line sideC = new Line(p3, p1);

	    // Create the triangle object
	    Triangle triangle = new Triangle(sideA, sideB, sideC);

	    // Print information about the triangle
	    System.out.println(triangle);
	    System.out.println("Perimeter: " + triangle.perimeter());
	    System.out.println("Area: " + triangle.area());
	  }
	}
