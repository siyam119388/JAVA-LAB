package Task8;

public class Triangle {
	  private Line sideA;
	  private Line sideB;
	  private Line sideC;

	  public Triangle(Line sideA, Line sideB, Line sideC) {
	    this.sideA = sideA;
	    this.sideB = sideB;
	    this.sideC = sideC;
	  }

	  public Line getSideA() {
	    return sideA;
	  }

	  public Line getSideB() {
	    return sideB;
	  }

	  public Line getSideC() {
	    return sideC;
	  }

	  public double perimeter() {
	    return sideA.getLength() + sideB.getLength() + sideC.getLength();
	  }

	  public double area() {
	    // Heron's formula
	    double s = perimeter() / 2;
	    double area = Math.sqrt(s * (s - sideA.getLength()) * (s - sideB.getLength()) * (s - sideC.getLength()));
	    return area;
	  }

	  @Override
	  public String toString() {
	    return "Triangle with sides: " + sideA + ", " + sideB + ", " + sideC;
	  }
	}
