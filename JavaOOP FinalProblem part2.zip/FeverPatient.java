/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package final_problem1;

public class FeverPatient extends PhysicalPatient{
    private double bodytemp;

    public FeverPatient(double bodytemp, boolean hasSymptoms, String name, int age) {
        super(hasSymptoms, name, age);
        this.bodytemp = bodytemp;
    }

   public void prescribeMed(String Medicine){
       System.out.println("Napa");
   }

    @Override
    public String toString() {
        return "FeverPatient{" + "bodytemp=" + bodytemp + '}';
    }
    
}
