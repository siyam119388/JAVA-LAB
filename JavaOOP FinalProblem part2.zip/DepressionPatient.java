/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package final_problem1;

/**
 *
 * @author LIB-602-IP-103
 */
public class DepressionPatient extends MentalPatient{
   private int duration;

    public DepressionPatient(int duration, boolean isAcute, String name, int age) {
        super(isAcute, name, age);
        this.duration = duration;
    }
   @Override
   public void  prescribeTherapy(String therapy){
       System.out.println("Therapy xy");
   }

    @Override
    public String toString() {
        return "DepressionPatient{" + "duration=" + duration + '}';
    }
    public void prescribeMed(String Medicine){
        
    }
}
