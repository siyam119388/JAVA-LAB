/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package final_problem1;

/**
 *
 * @author LIB-602-IP-103
 */
public class Final_Problem1 {

    public static void main(String[] args) {
       DepressionPatient d1=new   DepressionPatient(2,true,"Mr.ABC",40);
       AutismPatient A1=new   AutismPatient(false,true,"Mr.XYZ",60);
       AidsPatient A2=new  AidsPatient(2,true,"Mr.PQR",50);
       FeverPatient f1=new   FeverPatient(2,true,"Mr.abc",40);
        System.out.println(d1.toString());
        System.out.println(A1.toString());
        System.out.println(A2.toString());
        System.out.println(f1.toString());
    }
    
}
