/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package final_problem1;


public class AidsPatient extends PhysicalPatient{
    private int yearOfDiagnosis;

    public AidsPatient(int yearOfDiagnosis, boolean hasSymptoms, String name, int age) {
        super(hasSymptoms, name, age);
        this.yearOfDiagnosis = yearOfDiagnosis;
    }

    @Override
    public String toString() {
        return "AidsPatient{" + "yearOfDiagnosis=" + yearOfDiagnosis + '}';
    }
    
}
