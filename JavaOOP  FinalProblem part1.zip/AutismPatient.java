/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package final_problem1;

/**
 *
 * @author LIB-602-IP-103
 */
public class AutismPatient extends MentalPatient {
    private boolean isGenetic;

    public AutismPatient(boolean isGenetic, boolean isAcute, String name, int age) {
        super(isAcute, name, age);
        this.isGenetic = isGenetic;
    }
     @Override
   public void  prescribeTherapy(String therapy){
       System.out.println("Therapy xy");
   }

    @Override
    public String toString() {
        return "AutismPatient{" + "isGenetic=" + isGenetic + '}';
    }
}
