/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.polymorphismadvanceddemo;


public class PolymorphismAdvancedDemo {
    public static void main(String[] args) {
        EmployeeManagement management = new EmployeeManagement();

        // Adding employees using different overloaded methods
        management.addEmployee(new FullTimeEmployee("John Doe", 1, 5000));
        management.addEmployee("Jane Smith", 2, 40, 160); // Part-time
        management.addEmployee("Jack White", 3, 12000, true); // Contractor

        // Displaying all employees
        management.showAllEmployees();
    }
}
