package Task5;

public class Driver {

	  public static void main(String[] args) {
	    try {
	     
	      Fraction fraction1 = new Fraction(3, 20);
	      Fraction fraction2 = new Fraction(3, 5);

	      System.out.println("Fraction 1: " + fraction1);
	      System.out.println("Fraction 2: " + fraction2);

	      System.out.println("Addition: " + fraction1.add(fraction2));

	      System.out.println("Subtraction: " + fraction1.subtract(fraction2));
	      System.out.println("Multiplication: " + fraction1.multiply(fraction2));
	      System.out.println("Division: " +fraction1.divide(fraction2));

	    } catch (IllegalArgumentException e) {
	      System.err.println("Error: " + e.getMessage());
	    }
	  }
	}

