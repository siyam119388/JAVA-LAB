/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polymorphismadvanceddemo;
public class Contractor extends Employee {
    private double contractAmount;

    public Contractor(String name, int id, double contractAmount) {
        super(name, id);
        this.contractAmount = contractAmount;
    }

    @Override
    public double calculatePay() {
        return contractAmount;
    }

    @Override
    public void showEmployeeDetails() {
        super.showEmployeeDetails();
        System.out.println("Status: Contractor, Contract Amount: " + contractAmount);
    }
}
