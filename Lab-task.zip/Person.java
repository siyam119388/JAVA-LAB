package Task6;

public class Person {
	  private String fullName;
	  private String gender;
	  private String phoneNum;
	  private String email;
	  private Address presentAddress;
	  private Address permanentAddress;

	  public Person(String fullName, String gender, String phoneNum, String email, Address presentAddress, Address permanentAddress) {
	    this.fullName = fullName;
	    this.gender = gender;
	    this.phoneNum = phoneNum;
	    this.email = email;
	    this.presentAddress = presentAddress;
	    this.permanentAddress = permanentAddress;
	  }

	  

	  @Override
	  public String toString() {
	    return "Person{" +
	        "fullName='" + fullName + '\'' +
	        ", gender='" + gender + '\'' +
	        ", phoneNum='" + phoneNum + '\'' +
	        ", email='" + email + '\'' +
	        ", presentAddress=" + presentAddress +
	        ", permanentAddress=" + permanentAddress +
	        '}';
	  }
	}

