package Task6;

public class Address {
	  private int houseNum;
	  private int roadNum;
	  private String city;
	  private String country;
	  private String postalCode;

	  public Address(int houseNum, int roadNum, String city, String country, String postalCode) {
	    this.houseNum = houseNum;
	    this.roadNum = roadNum;
	    this.city = city;
	    this.country = country;
	    this.postalCode = postalCode;
	  }

	  // Getters and setters for all attributes (omitted for brevity)

	  @Override
	  public String toString() {
	    return "Address{" +
	        "houseNum=" + houseNum +
	        ", roadNum=" + roadNum +
	        ", city='" + city + '\'' +
	        ", country='" + country + '\'' +
	        ", postalCode='" + postalCode + '\'' +
	        '}';
	  }
	}
