package Task6;

public class Driver {

	  public static void main(String[] args) {
	    
	    Address presentAddress = new Address(101, 25, "Mountain View", "USA", "CA94043");
	    Address permanentAddress = new Address(50, 12, "San Jose", "USA", "CA95110");

	  
	    Person person = new Person("John Doe", "Male", "123-456-7890", "john.doe@email.com", presentAddress, permanentAddress);

	    
	    System.out.println(person);
	  }
	}
