/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polymorphismadvanceddemo;
import java.util.ArrayList;
import java.util.List;

public class EmployeeManagement {
    private List<Employee> employees;

    public EmployeeManagement() {
        employees = new ArrayList<>();
    }

    // Method Overloading
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void addEmployee(String name, int id, double monthlySalary) {
        employees.add(new FullTimeEmployee(name, id, monthlySalary));
    }

    public void addEmployee(String name, int id, double hourlyRate, int hoursWorked) {
        employees.add(new PartTimeEmployee(name, id, hourlyRate, hoursWorked));
    }

    public void addEmployee(String name, int id, double contractAmount, boolean isContractor) {
        if (isContractor) {
            employees.add(new Contractor(name, id, contractAmount));
        }
    }

    public void showAllEmployees() {
        for (Employee employee : employees) {
            employee.showEmployeeDetails();
            System.out.println("Calculated Pay: " + employee.calculatePay());
            System.out.println("--------------");
        }
    }
}
