package Task5;

public class Fraction {
	  private int numerator;
	  private int denominator;

	  
	  public Fraction(int numerator, int denominator) { 
	    this.numerator = numerator;
	    this.denominator = denominator;
	   
	  }

	  public int getNumerator() {
	    return numerator;
	  }

	  public void setNumerator(int numerator) {
	    this.numerator = numerator;
	  }

	  public int getDenominator() {
	    return denominator;
	  }

	  public void setDenominator(int denominator) {
	    if (denominator == 0) {
	      throw new IllegalArgumentException("Denominator cannot be zero");
	    }
	    this.denominator = denominator;
	  }

	  

	  public Fraction add(Fraction other) {
	    int newNumerator = this.numerator * other.denominator + other.numerator * this.denominator;
	    int newDenominator = this.denominator * other.denominator;
	    return new Fraction(newNumerator, newDenominator);
	  }

	  public Fraction subtract(Fraction other) {
		  int newNumerator = this.numerator * other.denominator - other.numerator * this.denominator;
		    int newDenominator = this.denominator * other.denominator;
		    return new Fraction(newNumerator, newDenominator);
	  }

	  public Fraction multiply(Fraction other) {
	    int newNumerator = this.numerator * other.numerator;
	    int newDenominator = this.denominator * other.denominator;
	    return new Fraction(newNumerator, newDenominator);
	  }

	  public Fraction divide(Fraction other) {
	    if (other.numerator == 0) {
	      throw new ArithmeticException("Division by zero");
	    }
	    return multiply(other.reciprocal());
	  }

	  public Fraction reciprocal() {
	    return new Fraction(this.denominator, this.numerator);
	  }

	  public String toString() {
	    return numerator + "/" + denominator;
	  }
	}
